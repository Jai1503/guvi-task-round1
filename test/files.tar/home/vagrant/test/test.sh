for file in {0..10}
do
	echo welcome > "$file.txt"
done
