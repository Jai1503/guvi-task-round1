read var1
read var2
if [ $var1=$var2 ]
then
	tar cvf files.tar /home/vagrant/test
	git add files.tar
	git commit -m "tar commit"
	git push origin main
else
	echo "not zipped"
fi
